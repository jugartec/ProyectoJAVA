package com.mindwaresrl.egpp.v0;

import java.io.BufferedReader;

public class Entidad {
	public boolean insert(BufferedReader fichero){
		 boolean result = false;

		 return result;
	}
	
	public boolean remove(BufferedReader fichero){
		return false;
	}
	
	public boolean  update(BufferedReader fichero){
		return false;
	}

}
