package com.mindwaresrl.egpp.v1.core;

public interface Entidad {
	public String getId();
}
