package com.mindwaresrl.egpp.v0;

public class Constantes {
	public static final String STR_VIVHABITUAL = "VH";   
	public static final String STR_VIVNOHABITUAL = "VNH";   

	public static final String STR_GRJABIERTA = "A";
	public static final String STR_GRJCERRADA = "C";
	public static final String STR_CONTRASTERO = "S";
	public static final String STR_SINTRASTERO = "N";
	
}